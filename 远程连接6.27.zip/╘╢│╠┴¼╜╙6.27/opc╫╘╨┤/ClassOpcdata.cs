﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace opc自写
{
    public class ClassOpcdata
    {
        public string Name { get; set; }
        public string Value { get; set; }
        public DateTime Time { get; set; }

    }
}
