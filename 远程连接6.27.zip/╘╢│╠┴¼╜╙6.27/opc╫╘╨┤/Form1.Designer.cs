﻿namespace opc自写
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.listBoxbrowers = new System.Windows.Forms.ListBox();
            this.buttonrefresh = new System.Windows.Forms.Button();
            this.buttondisconnect = new System.Windows.Forms.Button();
            this.buttonconnect = new System.Windows.Forms.Button();
            this.comboBox1server = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridViewvalue = new System.Windows.Forms.DataGridView();
            this.nameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.valueDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.timeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.classOpcdataBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewvalue)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.classOpcdataBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Controls.Add(this.listBoxbrowers);
            this.groupBox1.Controls.Add(this.buttonrefresh);
            this.groupBox1.Controls.Add(this.buttondisconnect);
            this.groupBox1.Controls.Add(this.buttonconnect);
            this.groupBox1.Controls.Add(this.comboBox1server);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(481, 534);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "OPC连接";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(369, 124);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(90, 40);
            this.button1.TabIndex = 9;
            this.button1.Text = "数据导出";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(19, 34);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(31, 15);
            this.label2.TabIndex = 8;
            this.label2.Text = "IP:";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(74, 32);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(274, 25);
            this.textBox1.TabIndex = 7;
            // 
            // listBoxbrowers
            // 
            this.listBoxbrowers.FormattingEnabled = true;
            this.listBoxbrowers.ItemHeight = 15;
            this.listBoxbrowers.Location = new System.Drawing.Point(15, 179);
            this.listBoxbrowers.Name = "listBoxbrowers";
            this.listBoxbrowers.Size = new System.Drawing.Size(446, 334);
            this.listBoxbrowers.TabIndex = 6;
            this.listBoxbrowers.DoubleClick += new System.EventHandler(this.listBoxbrowers_DoubleClick);
            // 
            // buttonrefresh
            // 
            this.buttonrefresh.Location = new System.Drawing.Point(133, 125);
            this.buttonrefresh.Name = "buttonrefresh";
            this.buttonrefresh.Size = new System.Drawing.Size(139, 38);
            this.buttonrefresh.TabIndex = 5;
            this.buttonrefresh.Text = "刷新服务器列表";
            this.buttonrefresh.UseVisualStyleBackColor = true;
            this.buttonrefresh.Click += new System.EventHandler(this.buttonrefresh_Click);
            // 
            // buttondisconnect
            // 
            this.buttondisconnect.Location = new System.Drawing.Point(369, 71);
            this.buttondisconnect.Name = "buttondisconnect";
            this.buttondisconnect.Size = new System.Drawing.Size(92, 39);
            this.buttondisconnect.TabIndex = 4;
            this.buttondisconnect.Text = "断开服务器";
            this.buttondisconnect.UseVisualStyleBackColor = true;
            this.buttondisconnect.Click += new System.EventHandler(this.buttondisconnect_Click);
            // 
            // buttonconnect
            // 
            this.buttonconnect.Location = new System.Drawing.Point(369, 22);
            this.buttonconnect.Name = "buttonconnect";
            this.buttonconnect.Size = new System.Drawing.Size(92, 39);
            this.buttonconnect.TabIndex = 3;
            this.buttonconnect.Text = "连接服务器";
            this.buttonconnect.UseVisualStyleBackColor = true;
            this.buttonconnect.Click += new System.EventHandler(this.buttonconnect_Click);
            // 
            // comboBox1server
            // 
            this.comboBox1server.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1server.FormattingEnabled = true;
            this.comboBox1server.Location = new System.Drawing.Point(74, 87);
            this.comboBox1server.Name = "comboBox1server";
            this.comboBox1server.Size = new System.Drawing.Size(274, 23);
            this.comboBox1server.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 87);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 15);
            this.label1.TabIndex = 1;
            this.label1.Text = "服务器：";
            // 
            // dataGridViewvalue
            // 
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewvalue.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewvalue.AutoGenerateColumns = false;
            this.dataGridViewvalue.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewvalue.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewvalue.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewvalue.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.nameDataGridViewTextBoxColumn,
            this.valueDataGridViewTextBoxColumn,
            this.timeDataGridViewTextBoxColumn});
            this.dataGridViewvalue.DataSource = this.classOpcdataBindingSource;
            this.dataGridViewvalue.Location = new System.Drawing.Point(487, 32);
            this.dataGridViewvalue.Name = "dataGridViewvalue";
            this.dataGridViewvalue.RowHeadersWidth = 51;
            this.dataGridViewvalue.RowTemplate.Height = 27;
            this.dataGridViewvalue.Size = new System.Drawing.Size(598, 481);
            this.dataGridViewvalue.TabIndex = 7;
            // 
            // nameDataGridViewTextBoxColumn
            // 
            this.nameDataGridViewTextBoxColumn.DataPropertyName = "Name";
            this.nameDataGridViewTextBoxColumn.HeaderText = "Name";
            this.nameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
            this.nameDataGridViewTextBoxColumn.Width = 200;
            // 
            // valueDataGridViewTextBoxColumn
            // 
            this.valueDataGridViewTextBoxColumn.DataPropertyName = "Value";
            this.valueDataGridViewTextBoxColumn.HeaderText = "Value";
            this.valueDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.valueDataGridViewTextBoxColumn.Name = "valueDataGridViewTextBoxColumn";
            this.valueDataGridViewTextBoxColumn.Width = 80;
            // 
            // timeDataGridViewTextBoxColumn
            // 
            this.timeDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.timeDataGridViewTextBoxColumn.DataPropertyName = "Time";
            this.timeDataGridViewTextBoxColumn.HeaderText = "Time";
            this.timeDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.timeDataGridViewTextBoxColumn.Name = "timeDataGridViewTextBoxColumn";
            // 
            // classOpcdataBindingSource
            // 
            this.classOpcdataBindingSource.DataSource = typeof(opc自写.ClassOpcdata);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1111, 536);
            this.Controls.Add(this.dataGridViewvalue);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "OPC client";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewvalue)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.classOpcdataBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button buttondisconnect;
        private System.Windows.Forms.Button buttonconnect;
        private System.Windows.Forms.ComboBox comboBox1server;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridViewvalue;
        private System.Windows.Forms.ListBox listBoxbrowers;
        private System.Windows.Forms.Button buttonrefresh;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn valueDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn timeDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource classOpcdataBindingSource;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button1;
    }
}

