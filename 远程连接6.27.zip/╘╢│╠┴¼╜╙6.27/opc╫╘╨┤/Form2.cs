﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace opc自写
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        MySqlConnection conn;
        DataSet ds;
        MySqlDataAdapter sda;

        private void Form2_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Owner.Show();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            conn = new MySqlConnection("server = localhost; user id = root; password = 103098; database = wzw");
            MySqlCommand cmd = new MySqlCommand("select * from opc", conn);
            sda = new MySqlDataAdapter();
            sda.SelectCommand = cmd;
            ds = new DataSet();
            sda.Fill(ds, "cs");
            dataGridView1.DataSource = ds.Tables[0];
        }
    }
}
