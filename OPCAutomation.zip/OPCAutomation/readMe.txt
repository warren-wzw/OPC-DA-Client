﻿将所有dll拷贝到C:/Windows/System32(64位机器还需往C:/windows/SysWOW64中拷贝一份),
用管理员身份打开cmd,cd到C:/Windows/System32(64位机器cd到C:/windows/SysWOW64),
然后输入regsvr32 OPCDAAuto.dll,最后重启电脑，完工。